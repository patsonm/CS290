document.addEventListener("DOMContentLoaded", loadTable);
//load table

//user id is key to table
function loadTable() {
    $.ajax({
        type: 'GET',
        url: "http://flip3.engr.oregonstate.edu:7642/get-workouts",
        success: function (workouts) {
            createRows(workouts);
        }
    })

}
//https://www.w3schools.com/jsref/prop_loc_search.asp to get ID
 $(document).ready(function() {
      if (window.location.pathname == '/input-row') {
        var id = Number(window.location.search.substring(4, window.location.search.length));
        $.ajax({
            type: 'GET',
            url: "http://flip3.engr.oregonstate.edu:7642/get-workout?id=" + id,
            success: function (data) {
                var rowData = JSON.parse(data)[0];
                document.getElementById("name").value = rowData.name;
                document.getElementById("weight").value = rowData.weight;
                document.getElementById("lbs").value = rowData.lbs;
                document.getElementById("reps").value = rowData.reps;
                document.getElementById("date").value = rowData.date;
                document.getElementsByTagName("div").id = id;
            }
        });
    }
 })

//modified from https://developer.mozilla.org/en-US/docs/Web/Guide/AJAX/Getting_Started
function submit () {
    var name = $('#name').val();
    var weight = $('#weight').val();
    var weightUnit = $('#weightUnit').val();
    var reps = $('#reps').val();
    var date = $('#date').val();
    var data = { id: null, name: name, weight: weight, weightUnit: weightUnit, reps: reps, date: date };
    $.ajax({
        type: 'GET',
        url: "http://flip3.engr.oregonstate.edu:7642/submit?name=" + name + "&weight=" + weight + "&weightUnit=" + weightUnit + "&reps=" + reps + "&date=" + date,
        success: function (id) {
            data.id = id;
            createRow(data);
        }
    });
}
//modified from https://developer.mozilla.org/en-US/docs/Web/Guide/AJAX/Getting_Started
function createRows(workouts) {
    var obj = JSON.parse(workouts.results);
    if (workouts != 0)
    {
        for (var x = 0; x < obj.length; x++){
        var row = $("<tr id=" + obj[x].id + "/>");
        $("#table").append(row);
        row.append($("<td>" + obj[x].name + "</td>"));
        row.append($("<td>" + obj[x].weight + "</td>"));
        row.append($("<td>" + obj[x].lbs + "</td>"));
        row.append($("<td>" + obj[x].reps + "</td>"));
        row.append($("<td>" + obj[x].date + "</td>"));
        row.append($('<td><input type="submit" value="Input" onclick="input(' + obj[x].id + ')"/>' +
        '<input type="submit" value="Delete" onclick="deleteRow(' + obj[x].id + ')"/></td>'));
        }
    }

}

function createRow(rowData) {
    var row = $("<tr id=" + rowData.id + "/>");
    $("#table").append(row);
    row.append($("<td>" + rowData.name + "</td>"));
    row.append($("<td>" + rowData.weight + "</td>"));
    row.append($("<td>" + rowData.weightUnit + "</td>"));
    row.append($("<td>" + rowData.reps + "</td>"));
    row.append($("<td>" + rowData.date + "</td>"));
    row.append($('<td><input type="submit" value="Input" onclick="input(' + rowData.id + ')"/>' +
        '<input type="submit" value="Delete" onclick="deleteRow(' + rowData.id + ')"/></td>'));
}

function save() {
    var name = $('#name').val();
    var weight = $('#weight').val();
    var lbs = $('#lbs').val();
    var reps = $('#reps').val();
    var date = $('#date').val();
    var id = document.getElementsByTagName('div').id;
    $.ajax({
        type: 'GET',
        url: "http://flip3.engr.oregonstate.edu:7642/input-save?id=" + id + "&name=" + name + "&weight=" + weight + "&lbs=" + lbs + "&reps=" + reps + "&date=" + date,
        success: function () {
            window.location = "http://flip3.engr.oregonstate.edu:7642/";
        }
    });
}
//copied formatting, https://www.w3schools.com/xml/ajax_intro.asp
function deleteRow(id) {
    $.ajax({
        type: 'GET',
        url: "http://flip3.engr.oregonstate.edu:7642/delete?id=" + id,
        success: function () 
        {
            $("#" + id).remove();
        }
    });
}
//copied formatting, https://www.w3schools.com/xml/ajax_intro.asp
function input(id) {
    $.ajax({
        type: 'GET',
        url: "http://flip3.engr.oregonstate.edu:7642/get-workout?id=" + id,
        success: function (data) 
        {
            var rowData = JSON.parse(data)[0];            
            window.location = "http://flip3.engr.oregonstate.edu:7642/input-row?id=" + rowData.id;

        }
    });
}